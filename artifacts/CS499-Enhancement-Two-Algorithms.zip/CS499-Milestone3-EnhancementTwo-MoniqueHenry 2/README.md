# CS 499 Milestone Three — Enhancement Two

**Student:** Monique Henry  
**Category:** Algorithms and Data Structures

## Package contents

- `original/` — Original CS 340 artifact files. Hardcoded connection values were redacted for submission safety.
- `working_baseline/` — Local compatibility baseline used before the Enhancement Two implementation. Connection values were redacted where applicable.
- `enhanced/` — Completed Rescue Match Recommendation Dashboard, automated tests, and test evidence.
- `supporting_files/` — Dataset and logo required to understand or reproduce the artifact.

## Enhancement Two highlights

- Dictionary and set indexes for candidate lookup
- Binary search over sorted age values
- Weighted recommendation scoring
- Bounded min-heap for top-k selection
- Recommendation caching
- Dash dashboard integration
- Automated recommendation and service-level tests

## Run the tests

From the `enhanced` directory:

```bash
python -m pip install -r requirements.txt
python -m pytest -v
```

The completed local project test run reported **82 passed**.

## Run the dashboard

Start the local MongoDB service and ensure the `aac.animals` collection is available. Then, from the `enhanced` directory, run:

```bash
python app.py
```

Open `http://127.0.0.1:8050` in a browser.

## Security note

No active `.env` file is included. The `.env.example` file contains only non-secret configuration examples. Original hardcoded connection values were replaced with redacted placeholders in this submission copy.
