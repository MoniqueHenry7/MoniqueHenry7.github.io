# SNHU CS 340: Client/Server Development 
# Project Two: Grazioso Salvare Dashboard 
# Original Author: Monique Henry
# Original Instructor: Dr.Ostrowski
#
# CS 499 Code Review Working Copy
# Purpose: Preserve and demonstrate the original artifact for code review.
# Revising Scope: Limited compatibility changes were made to support the 
# current local MongoDB and Python environments. The planned CS 499
# enhancements have not yet been implemented.
# Original CS 340 files are preserved separately.
# Code Review Preparation Date: July 8, 2026

from pymongo import MongoClient
from pymongo.errors import PyMongoError  #adding PyMongoError for exception handling best practices
from bson.objectid import ObjectId

class AnimalShelter(object):
    """CRUD operations for Animal collection in MongoDB"""
    
    def __init__(self, username, password, host, port, db, col): # Updated contructor with additional parameters
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections.
        # This is hard-wired to use the aac database, the
        # animals collection, and the aac user.
        # Definitions of the connection string variables are
        # unique to the individual Apporto environment.
        #
        # You must edit this connection variables below to reflect
        # your own instance of MongoDB!
        #
        # Connection Variables
        # MongoDB connection credentials and config.
        # Previous constructor accepts connection parameters, but then ignores them and 
        # uses the old hardcoded Apporto host, credentials, and port from CS 340 course.
        #
        #USER = 'REDACTED_USERNAME'
        #PASS = '[Redacted]' # password was not changed for ease/continuity.
        #HOST = 'REDACTED_HOST'
        #PORT = 31707      # updated port
        #DB = 'aac'
        #COL = 'animals'
        #
        # Initialize Connection
        # Using try-except blocks to handle connection/authentication, (exception handling)
        #
        #try:
        #    # Connect to MongoDB with authentication
        #    self.client = MongoClient(f"mongodb://REDACTED_USERNAME:REDACTED_PASSWORD@{HOST}:{PORT}")
        #    self.database = self.client[DB]
        #    self.collection = self.database[COL]
        #    print("Connected to MongoDB successfully.")
        #except PyMongoError as e:
        #    print(f"[ERROR] MongoDB connection failed: {e}")
        #    raise

        # update to view/run artifact
        """Connect to the requested MongoDB database and collection."""

        try:
            # Connect to the locally running MongoDB server.
            # Local MongoDB currently does not require authentication.
            self.client = MongoClient(
                host=host,
                port=port,
                serverSelectionTimeoutMS=5000
            )

            # Force MongoDB to verify that the server is reachable.
            self.client.admin.command("ping")

            self.database = self.client[db]
            self.collection = self.database[col]

            print(f"Connected to MongoDB: {db}.{col}")

        except PyMongoError as error:
            print(f"[ERROR] MongoDB connection failed: {error}")
            raise

        
    # Complete this create method to implement the C in CRUD.
    def create(self, data):
            # Check that the input is a non-empty dictionary
            if data is not None and isinstance(data, dict):
                try:
                    # Insert the document into the collection
                    result = self.database.animals.insert_one(data)
                    return result.acknowledged  # Return True if insert succeeded, else False
                except PyMongoError as e:
                    print(f"[ERROR] Insert failed: {e}")
                    return False
            else:
                raise Exception("Nothing to save, because data parameter is empty")
                
    # Create method to implement the R in CRUD.
    def read(self, query):
            # Validate that the query is a dictionary
            if query is not None and isinstance(query, dict):
                try:
                    # Find all documents matching the query
                    cursor = self.database.animals.find(query)  # find() returns a cursor
                    return list(cursor)                         # Convert the cursor to a list and return
                except PyMongoError as e:
                    print(f"[ERROR] Read failed: {e}")
                    return []
            else:
                raise Exception("Invalid query: because data parameter is empty.")
                
    # Update method to implement the U in CRUD.
    def update(self, query, update_data):
        # Update a document or documents based on the query and update data.
        # :param query: Dictionary to locate the document(s) to be updated
        # :param update_data: Dictionary with key/value pairs to update
        # :return: Number of documents modified
        if query and isinstance(query, dict) and update_data and isinstance(update_data, dict):
            try:
                # Use the $set operator to modify specific fields in the document
                result = self.database.animals.update_many(query, {"$set": update_data})
                return result.modified_count # Number of documents modified
            except PyMongoError as e:
                print(f"[ERROR] Update failed: {e}")
                return 0
        else:
            raise Exception("Invalid query or update data")
            
    # Delete method to implement the D in CRUD.
    def delete(self, query):
        # Delete a document or documents based on the query.
        # :param query: Dictionary to locate the document(s) to be deleted
        # :return: Number of documents removed
        if query and isinstance(query, dict):
            try:
                # Delete the document(s) matching the query
                result = self.database.animals.delete_many(query)
                return result.deleted_count # Number of documents deleted
            except PyMongoError as e:
                print(f"[ERROR] Delete failed: {e}")
                return 0
        else:
            raise Exception("Invalid query parameter")
        
                      