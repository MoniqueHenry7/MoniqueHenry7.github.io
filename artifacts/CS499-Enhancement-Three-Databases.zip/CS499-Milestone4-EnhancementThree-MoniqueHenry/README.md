# CS 499 Milestone Four: Enhancement Three — Databases

**Student:** Monique Henry
**Course:** CS 499 Computer Science Capstone
**Artifact:** Grazioso Salvare Rescue Match Recommendation Dashboard
**Enhancement Category:** Databases
**Completion Date:** July 2026

---

## Project Overview

This project is an enhanced version of the Grazioso Salvare dashboard originally created for CS 340 Client/Server Development.

The original application used Python, Dash, Pandas, MongoDB, and a custom `AnimalShelter` CRUD class to display animal shelter records from the Austin Animal Center dataset. Users could select rescue categories, review matching records in an interactive table, view breed information in a chart, and display the selected animal’s location on a map.

For CS 499 Enhancement Three, the original database implementation was transformed into a more secure, validated, indexed, and maintainable MongoDB data service.

The original collection remains preserved as:

```text
aac.animals
```

The enhanced dashboard now uses:

```text
aac.animals_enhanced
```

Database mutation activity is recorded in:

```text
aac.audit_logs
```

The enhanced database remains compatible with the modular architecture completed during Enhancement One and the recommendation algorithms completed during Enhancement Two.

---

## Enhancement Three Goals

Enhancement Three was designed to demonstrate advanced database-development skills through the following improvements:

* MongoDB JSON Schema validation
* Controlled source-data migration
* Data cleaning and normalization
* Generated record-specific identifiers
* Database-side filtering
* Field projections
* Sorting and pagination
* Distinct-value queries
* Aggregation pipelines
* Purpose-built MongoDB indexes
* Query execution-plan evaluation
* Secure record-specific CRUD operations
* Original-collection protection
* Explicit deletion confirmation
* Automatic audit logging
* Environment-based configuration
* Dashboard and recommendation-engine integration
* Automated and manual testing

These improvements transformed MongoDB from a basic storage connection into a structured application data service.

---

## Database Architecture

The enhanced application uses three MongoDB collections.

### `animals`

The original Austin Animal Center source collection.

This collection is preserved so the original artifact remains available for comparison. Secure create, update, and delete methods reject mutation attempts when the application is connected to this collection.

### `animals_enhanced`

The validated and normalized operational collection used by the completed dashboard.

The migration process transferred the source records into this collection without modifying the original `animals` collection.

### `audit_logs`

The audit collection records successful and rejected database mutation attempts.

Audit entries may include:

* Operation type
* Record UID
* Original animal identifier
* Timestamp
* User or process performing the operation
* Fields changed
* Success or failure status
* Error details

---

## Major Database Improvements

### Validated database schema

The `animals_enhanced` collection uses MongoDB JSON Schema validation to control:

* Required fields
* Approved field names
* BSON data types
* Minimum age values
* Latitude boundaries
* Longitude boundaries
* Generated record identifiers
* Migration timestamps

The enhanced collection uses strict validation so records that do not comply with the approved schema are rejected.

### Controlled data migration

Records are read from:

```text
aac.animals
```

and written to:

```text
aac.animals_enhanced
```

The migration process:

* Preserves the original source records
* Generates a unique `record_uid` for each database record
* Preserves the original `animal_id`
* Standardizes approved text values
* Converts age values into numeric weeks
* Converts location values into numeric coordinates
* Checks geographic boundaries
* Normalizes missing and invalid values
* Validates each record before insertion
* Records migration activity in the audit collection

The source dataset contains 10,000 records, and all 10,000 records were migrated into the enhanced collection.

Because some animals have multiple shelter outcome records, `animal_id` is not treated as unique. The generated `record_uid` is used for record-specific reads, updates, deletions, and audit entries.

### Controlled query construction

The enhanced data-access layer builds MongoDB queries only from approved fields.

Supported filters include:

* Animal type
* Breed
* Outcome type
* Sex upon outcome
* Minimum age
* Maximum age

The application validates:

* Filter names
* Projection fields
* Sort fields
* Sort directions
* Page numbers
* Page sizes
* Age boundaries

Invalid or unsupported query options are rejected before being sent to MongoDB.

### Database-side filtering

The dashboard no longer needs to load the full collection before applying its primary filters.

MongoDB now performs:

* Breed filtering
* Outcome filtering
* Age-range filtering
* Animal-type filtering
* Sex filtering
* Sorting
* Projection
* Pagination
* Distinct-value retrieval
* Age-bound aggregation

Only approved matching records are returned to the application.

After MongoDB narrows the candidate set, the Enhancement Two recommendation engine ranks the candidates and generates recommendation scores and explanations.

### Pagination

The enhanced read interface performs database-side pagination.

Each paginated result includes:

* Current page
* Page size
* Total matching records
* Total pages
* Records for the requested page

Page sizes are restricted to approved values to prevent unrestricted collection reads.

### Aggregation pipelines

MongoDB aggregation pipelines are used to calculate database summaries.

These include:

* Minimum animal age
* Maximum animal age
* Outcome-type totals
* Dashboard summary values

The dashboard’s age boundaries are retrieved from MongoDB instead of being permanently hardcoded.

Breed and outcome dropdown values are also retrieved directly from the database.

---

## Indexing and Performance

Enhancement Three adds indexes based on the dashboard’s actual query patterns.

Indexes include:

```text
record_uid
```

```text
animal_type, breed, age_in_weeks
```

```text
animal_type, outcome_type, age_in_weeks
```

```text
animal_id
```

```text
outcome_date
```

The audit collection also includes a timestamp index.

Representative breed-and-age and outcome-and-age queries were evaluated before and after index creation.

Before optimization, the test queries performed full collection scans across the 10,000-record collection.

After optimization, MongoDB selected the intended indexes and examined only the keys and documents associated with the matching results.

Query-plan evidence is included in the Enhancement Three documentation folder.

---

## Secure CRUD Operations

The enhanced `AnimalShelter` class provides secure record-specific methods for:

* Creating one animal record
* Reading one record by `record_uid`
* Updating one record by `record_uid`
* Deleting one record by `record_uid`

Security safeguards include:

* Approved-field allowlists
* Required-field validation
* Data-type validation
* Numeric-boundary validation
* Geographic-boundary validation
* Duplicate-key handling
* Record-specific update criteria
* Record-specific deletion criteria
* Explicit deletion confirmation
* Original-collection protection
* Success audit logging
* Failure audit logging

Broad update and delete operations are not used by the secure mutation interface.

Secure mutation methods operate only on:

```text
animals_enhanced
```

Attempts to modify the protected original `animals` collection are rejected.

Deletion requires both a valid `record_uid` and explicit confirmation.

---

## Secure Configuration

MongoDB settings are managed through the `AppConfig` class in:

```text
enhanced/config.py
```

Supported environment variables include:

```text
MONGO_HOST
MONGO_PORT
MONGO_DB
MONGO_COLLECTION
MONGO_USERNAME
MONGO_PASSWORD
DASH_DEBUG
```

Safe local defaults are:

```text
MONGO_HOST=127.0.0.1
MONGO_PORT=27017
MONGO_DB=aac
MONGO_COLLECTION=animals_enhanced
DASH_DEBUG=false
```

MongoDB authentication is optional for local development.

When authentication is enabled, both `MONGO_USERNAME` and `MONGO_PASSWORD` must be supplied.

No active `.env` file or production credentials are included in the submission package.

---

## Dashboard Integration

The completed application follows this general flow:

```text
config.py
    ↓
animal_shelter.py
    ↓
dashboard_service.py
    ↓
recommendation.py and rescue_rules.py
    ↓
app.py
   ↙   ↘
ui.py  callbacks.py
```

The database layer handles:

* Validated data storage
* Query construction
* Filtering
* Sorting
* Projection
* Pagination
* Distinct values
* Aggregation
* Secure CRUD operations
* Audit logging

The Enhancement Two recommendation engine retains:

* Dictionary-based indexes
* Set-based candidate intersections
* Binary search over sorted age values
* Weighted recommendation scoring
* Bounded top-k candidate selection
* Recommendation caching
* Match explanations

---

## Dashboard Features

The enhanced dashboard includes:

* Rescue-category selection
* Breed filtering
* Outcome filtering
* Database-generated dropdown options
* Database-generated age boundaries
* Interactive age-range filtering
* Paginated animal records
* Rescue recommendation scores
* Recommendation explanations
* Breed distribution chart
* Interactive location map
* Reset controls
* Database-backed table, chart, and map updates

Manual testing confirmed that the dashboard connects to `aac.animals_enhanced`, loads database-driven filter values, displays records, produces recommendations, and updates the chart and map without a traceback.

---

## Project Structure

```text
CS499-Milestone4-EnhancementThree-MoniqueHenry/
│
├── README.md
│
├── original/
│   ├── ProjectTwoDashboard-MoniqueHenry.ipynb
│   └── animal_shelter.py
│
├── working_baseline/
│   ├── ProjectTwoDashboard-LocalWorkingCopy.ipynb
│   └── animal_shelter-LocalWorkingCopy.py
│
├── enhanced/
│   ├── EnhancementThree-DatabaseDevelopment.ipynb
│   ├── ProjectTwoDashboard-Enhanced.ipynb
│   ├── animal_shelter.py
│   ├── app.py
│   ├── callbacks.py
│   ├── config.py
│   ├── dashboard_service.py
│   ├── database_indexes.py
│   ├── database_migration.py
│   ├── database_setup.py
│   ├── recommendation.py
│   ├── rescue_rules.py
│   ├── ui.py
│   ├── requirements.txt
│   ├── .env.example
│   ├── .gitignore
│   │
│   ├── tests/
│   │
│   └── docs/
│       ├── enhancement-two/
│       └── enhancement-three/
│
└── supporting_files/
    ├── aac_shelter_outcomes.csv
    └── Grazioso Salvare Logo.png
```

### Folder descriptions

#### `original`

Contains the original CS 340 artifact before the CS 499 enhancements.

#### `working_baseline`

Contains the local working version used as the starting point for the CS 499 enhancements.

#### `enhanced`

Contains the completed application, database-development notebook, source modules, tests, and technical evidence.

#### `supporting_files`

Contains the Austin Animal Center dataset and Grazioso Salvare logo.

---

## Requirements

The project uses:

* Python 3
* MongoDB
* MongoDB Shell
* Jupyter Notebook
* Dash
* Dash Leaflet
* Pandas
* Plotly
* PyMongo
* Pytest

Python dependencies are listed in:

```text
enhanced/requirements.txt
```

---

## Local Setup

### 1. Start MongoDB

Start the local MongoDB service.

For a Homebrew installation:

```bash
brew services start mongodb-community
```

Confirm that MongoDB is available:

```bash
mongosh
```

### 2. Import the source dataset

Navigate to the `enhanced` directory.

The dataset is located at:

```text
../supporting_files/aac_shelter_outcomes.csv
```

Import the source records:

```bash
mongoimport \
  --db aac \
  --collection animals \
  --type csv \
  --headerline \
  --file "../supporting_files/aac_shelter_outcomes.csv"
```

To intentionally replace an existing local source collection, add `--drop`:

```bash
mongoimport \
  --db aac \
  --collection animals \
  --type csv \
  --headerline \
  --drop \
  --file "../supporting_files/aac_shelter_outcomes.csv"
```

The `--drop` option deletes the existing target collection before importing the CSV.

Verify the import:

```bash
mongosh
```

Then run:

```javascript
use aac
db.animals.countDocuments({})
```

Expected source-record count:

```text
10000
```

### 3. Create a virtual environment

From the `enhanced` directory:

```bash
python3 -m venv .venv
```

Activate it:

```bash
source .venv/bin/activate
```

### 4. Install dependencies

```bash
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

### 5. Configure the application

The application defaults to:

```text
127.0.0.1:27017
aac.animals_enhanced
```

Environment variables can be set with:

```bash
export MONGO_HOST="127.0.0.1"
export MONGO_PORT="27017"
export MONGO_DB="aac"
export MONGO_COLLECTION="animals_enhanced"
export DASH_DEBUG="false"
```

For a database requiring authentication:

```bash
export MONGO_USERNAME="your_username"
export MONGO_PASSWORD="your_password"
```

Do not include actual credentials in the project files or submission ZIP.

---

## Create the Enhanced Database

The primary database-development workflow is contained in:

```text
EnhancementThree-DatabaseDevelopment.ipynb
```

Start Jupyter Notebook:

```bash
jupyter notebook
```

Open the database-development notebook and run the cells in order.

The notebook performs:

1. MongoDB connection validation
2. Original database audit
3. Validated collection setup
4. Audit collection setup
5. Source-data migration
6. Migration validation
7. Index creation
8. Query-plan comparisons
9. Paginated-read testing
10. Distinct-value testing
11. Aggregation testing
12. Secure CRUD testing
13. Audit-log testing
14. Source-collection safeguard testing
15. Dashboard-service integration testing

After running the notebook, verify the collections:

```javascript
use aac
show collections
```

Expected collections:

```text
animals
animals_enhanced
audit_logs
```

Verify the enhanced record count:

```javascript
db.animals_enhanced.countDocuments({})
```

Expected result:

```text
10000
```

---

## Run the Automated Tests

From the `enhanced` directory:

```bash
source .venv/bin/activate
python -m pytest -v
```

The completed automated test suite reported:

```text
84 passed
```

The tests cover:

* CSV availability
* Rescue rules
* Recommendation algorithms
* Dashboard-service integration
* Pagination
* Query validation
* Projection validation
* Sort validation
* Secure CRUD behavior
* Required-field validation
* Geographic-boundary validation
* Configuration safeguards
* Original-collection protection
* Explicit deletion confirmation
* Audit logging
* Recommendation-engine compatibility

---

## Run the Dashboard

Confirm that:

1. MongoDB is running.
2. The `aac` database exists.
3. The `animals_enhanced` collection exists.
4. The virtual environment is active.

Run:

```bash
python app.py
```

The application should report:

```text
MongoDB database: aac
MongoDB collection: animals_enhanced
Dashboard address: http://127.0.0.1:8050/
```

Open:

```text
http://127.0.0.1:8050/
```

Press `Control+C` in Terminal to stop the dashboard.

---

## Evidence and Documentation

Enhancement Three evidence is located in:

```text
enhanced/docs/enhancement-three/
```

The documentation includes evidence of:

* Original database auditing
* Validated collection setup
* Source-data migration
* Index creation
* Query execution plans
* Read-layer behavior
* Secure CRUD operations
* Audit logging
* Automated testing
* Dashboard runtime behavior
* Manual dashboard testing
* Technical design decisions

Representative evidence files include:

```text
ENHANCEMENT_THREE_DATABASE_AUDIT.json
ENHANCEMENT_THREE_DATABASE_SETUP.json
ENHANCEMENT_THREE_MIGRATION_RESULTS.json
ENHANCEMENT_THREE_INDEX_COMPARISON.csv
ENHANCEMENT_THREE_INDEX_SUMMARY.txt
ENHANCEMENT_THREE_READ_LAYER_RESULTS.json
ENHANCEMENT_THREE_SECURE_CRUD_RESULTS.json
ENHANCEMENT_THREE_FINAL_TEST_RESULTS.txt
ENHANCEMENT_THREE_DASHBOARD_RUNTIME.txt
ENHANCEMENT_THREE_DASHBOARD_MANUAL_TESTS.md
ENHANCEMENT_THREE_TECHNICAL_REPORT.md
ENHANCEMENT_THREE_EVIDENCE_INDEX.md
```

Query-plan evidence includes:

```text
QUERY_PLAN_BEFORE_BREED_AGE.json
QUERY_PLAN_AFTER_BREED_AGE.json
QUERY_PLAN_BEFORE_OUTCOME_AGE.json
QUERY_PLAN_AFTER_OUTCOME_AGE.json
```

---

## Security Considerations

Enhancement Three applies the following security practices:

* Database configuration is separated from application logic
* Credentials can be supplied through environment variables
* No active credential file is included
* Query fields are controlled through allowlists
* Mutation fields are controlled through allowlists
* Required values are validated
* Numeric and geographic boundaries are validated
* Updates target one generated record UID
* Deletions target one generated record UID
* Deletion requires explicit confirmation
* The original source collection is protected
* Successful mutations are audited
* Rejected mutations are audited
* Database errors are handled without exposing credentials

This application was created as a local academic development project. The Dash development server should not be used as a production deployment server.

---

## Course Outcome Alignment

Enhancement Three demonstrates progress toward the CS 499 program outcomes by:

* Supporting organizational decision-making through validated and consistent database records
* Communicating results through filters, tables, charts, maps, recommendation summaries, and technical documentation
* Evaluating database-design trade-offs involving data quality, schema strictness, unique identifiers, indexes, storage, and performance
* Applying MongoDB validation, migration, aggregation, pagination, indexing, secure CRUD operations, and audit logging to an industry-focused problem
* Applying a security mindset through controlled queries, mutation safeguards, environment-based configuration, source-data protection, deletion confirmation, and auditability

---

## Author

**Monique Henry**
Southern New Hampshire University
CS 499 Computer Science Capstone
July 2026

---

## Academic Project Notice

Grazioso Salvare is a fictional organization used for academic coursework.

The Austin Animal Center dataset is included as supporting data for educational and portfolio purposes.
